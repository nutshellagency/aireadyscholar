# Declaration of AI use (draft)

No AI use recorded yet. This draft is rebuilt from logs/ai-use-log.csv each time a skill updates the log.
Check and edit it before you use it. The wording and placement rules are in 06-AI-Use-Declaration.docx.
