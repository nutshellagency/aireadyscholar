Files the skills create go here: gap report, research-question review, questionnaire blueprint. Your own writing goes in the Word skeletons.
