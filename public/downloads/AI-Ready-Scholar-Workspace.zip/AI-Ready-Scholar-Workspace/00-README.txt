AI-Ready Scholar workspace
==========================
Keep this folder for your whole thesis. Turn on version history (OneDrive, Google Drive) so every change is dated.

01-Research-Logs.xlsx            AI-use log, search log, reading matrix, gap evidence, decision log, criteria checklist
02-References/                   your Zotero or EndNote library export goes here
03-Data/                         your own data only (questionnaires, photos, transcripts). Never AI-generated.
04-Thesis-Skeleton-*.docx        chapter headings with guidance questions; choose linguistics or literature
05-Research-Article-Skeleton.docx  for a journal paper; follow the journal's own guidelines first
06-AI-Use-Declaration.docx       where and how to declare AI use, with templates

The rule: the structure guides, the content is yours. AI tools search, count, check and give feedback.
You read, decide and write.

Every AI skill answer ends with an "AI-use log line". Paste it into the AI-use log sheet the same day,
then fill in "My decision" yourself. Your declaration is written from this log, nothing else.
