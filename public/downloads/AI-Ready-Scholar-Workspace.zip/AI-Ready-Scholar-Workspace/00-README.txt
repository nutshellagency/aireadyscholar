AI-Ready Scholar workspace · pack version 1.1.0 (2026-11-11)
==========================================================
Latest version and setup steps: https://aireadyscholar.vercel.app/kit
Keep this folder for your whole thesis. Turn on version history (OneDrive, Google Drive) so every change is dated.

01-Research-Logs.xlsx            reading matrix, gap evidence, criteria checklist (you fill these)
logs/                            ai-use-log.csv, search-log.csv, decision-log.csv, disclosure-draft.md
                                 The AI skills update these themselves when they can reach this folder
                                 (Claude desktop with this folder connected, or Claude Code with your repo).
                                 Otherwise paste the row they print. All open in Excel.
notes/                           what the skills produce: gap report, question review, questionnaire blueprint
02-References/                   your Zotero or EndNote library export goes here
03-Data/                         your own data only (questionnaires, photos, transcripts). Never AI-generated.
04-Thesis-Skeleton-*.docx        chapter headings with guidance questions; choose linguistics or literature
05-Research-Article-Skeleton.docx  for a journal paper; follow the journal's own guidelines first
06-AI-Use-Declaration.docx       where and how to declare AI use, with templates

The rule: the structure guides, the content is yours. AI tools search, count, check and give feedback.
You read, decide and write.

Tip: keep this folder in a private GitHub repository. Each log update then becomes a dated commit,
a record your supervisor can trust. Fill in "my decision" yourself; the AI never does.
